export type CoinSpecs = CoinSpec[];
export interface DerivationSpec {
    name: string;
    path: string;
    xpub: string;
    xprv: string;
}
export interface ExplorerSpec {
    url: string;
    txPath: string;
    accountPath: string;
    sampleTx: string;
    sampleAccount: string;
}
export interface InfoSpec {
    url: string;
    source: string;
    rpc: string;
    documentation: string;
}
export interface CoinSpec {
    id: string;
    name: string;
    coinId: number;
    symbol: string;
    decimals: number;
    blockchain: string;
    derivation: DerivationSpec[];
    curve: string;
    publicKeyType: string;
    p2pkhPrefix: number;
    p2shPrefix: number;
    hrp: string;
    publicKeyHasher: string;
    base58Hasher: string;
    explorer: ExplorerSpec;
    info: InfoSpec;
}
